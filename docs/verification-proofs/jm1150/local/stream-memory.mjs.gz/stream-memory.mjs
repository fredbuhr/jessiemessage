import { fork } from "node:child_process";
import { readFile } from "node:fs/promises";
import { Readable } from "node:stream";
import { createImagePreparer } from "file:///workspace/scratch/2a0dbdfc70cc/jessiemessage-audit/server/media/image.mjs";
const mode = process.argv[2];
const source = await readFile(new URL(mode.includes("png") ? "./synthetic-48mp-interlaced.png" : "./jpeg-control.jpg", import.meta.url));
const length = 75 * 1024 * 1024, padding = Buffer.alloc(64 * 1024);
let workerUsage, workerMemory;
const prepare = createImagePreparer({ forkProcess(url, args, options) {
  const child = fork(new URL("./stream-memory-worker.mjs", import.meta.url), args, { ...options, stdio: ["pipe", "ignore", "pipe", "ipc"] });
  child.stderr.on("data", bytes => process.stderr.write(bytes));
  child.on("exit", (code, signal) => { console.error(JSON.stringify({childExit:code,childSignal:signal})); });
  child.on("message", message => { workerUsage = message.probeUsage; workerMemory = message.probeMemory; });
  return child;
}});
async function* input() { yield source; let remaining = length - source.length; while (remaining) { const count = Math.min(padding.length, remaining); yield padding.subarray(0, count); remaining -= count; } }
const started = performance.now();
try {
const result = await prepare(Readable.from(input()), { declaredBytes: mode.includes("chunked") ? null : length });
console.log(JSON.stringify({ mode, originalBytes: length, baseBytes: source.length, outputBytes: result.full.length, width: result.width, height: result.height, elapsedMs: performance.now() - started, parentUsage: process.resourceUsage(), workerUsage, workerMemory }));
} catch(error) { console.log(JSON.stringify({mode,error:error.code,elapsedMs:performance.now()-started,parentUsage:process.resourceUsage(),workerUsage,workerMemory})); process.exitCode=1; }
