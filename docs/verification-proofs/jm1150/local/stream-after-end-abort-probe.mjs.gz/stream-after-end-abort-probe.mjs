import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createImagePreparer } from './frozen-stream-image-592b8263.mjs';

const timers = [], child = new EventEmitter();
child.pid = 123; child.stdin = new EventEmitter();
child.stdin.write = () => true; child.stdin.end = () => {}; child.stdin.destroy = () => {};
child.send = (_configuration, callback) => callback(null);
child.kill = signal => { child.killed = signal; return true; };
const prepare = createImagePreparer({ forkProcess: () => child,
  setTimer(callback, delay) { const value = { callback, delay, unref() {} }; timers.push(value); return value; }, clearTimer() {} });
const source = new EventEmitter(); source.pause = () => {}; source.resume = () => {};
const pending = prepare(source, { declaredBytes: 4 });
const rejected = assert.rejects(pending, error => error.code === 'MEDIA_UNAVAILABLE');
source.emit('data', Buffer.from([255, 216, 255, 217])); source.emit('end');
assert.equal(source.listenerCount('aborted'), 0); assert.equal(source.listenerCount('close'), 0);
source.emit('aborted'); source.emit('close');
assert.equal(child.killed, undefined, 'disconnect after end does not stop the image child');
const next = new EventEmitter(); next.pause = () => {}; next.resume = () => {};
await assert.rejects(prepare(next), error => error.code === 'MEDIA_BUSY');
assert.equal(timers.at(-1).delay, 30000);
timers.at(-1).callback(); assert.equal(child.killed, 'SIGKILL');
child.emit('exit', null, 'SIGKILL'); await rejected;
process.stdout.write(JSON.stringify({ source: '592b826353b46f01f474ba8bf1aa01c66fee997c',
  originalBodyEnded: true, disconnectObservedByChild: false, globalPreparationStillBusy: true,
  onlyDecodeDeadlineStopsChildMilliseconds: 30000, realChildOrMediaFilesCreated: false }) + '\n');
