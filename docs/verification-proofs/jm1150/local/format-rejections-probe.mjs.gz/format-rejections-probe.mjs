import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import { inspectImageInput } from '../../jessiemessage-audit/public/image-preparation.js';
const sharp=createRequire(new URL('../../jessiemessage-audit/package.json',import.meta.url))('sharp');
const dir=new URL('./',import.meta.url);
const width=32,height=24;
const raw=Buffer.alloc(width*height*3);
for(let y=0;y<height;y++)for(let x=0;x<width;x++){
 const i=(y*width+x)*3;raw[i]=x<width/2?230:30;raw[i+1]=y<height/2?30:220;raw[i+2]=80;
}
const second=Buffer.from(raw);for(let i=0;i<second.length;i+=3){second[i]=20;second[i+2]=220;}
const ffi=(args,input)=>execFileSync('ffmpeg',['-v','error',...args],{input,maxBuffer:1024*1024});
const staticImage=()=>sharp(raw,{raw:{width,height,channels:3}});
const fixtures=[
 {name:'gif-static.gif',mime:'image/gif',bytes:await staticImage().gif().toBuffer(),reference:'sharp'},
 {name:'gif-animated.gif',mime:'image/gif',bytes:await sharp(Buffer.concat([raw,second]),{raw:{width,height:height*2,channels:3,pageHeight:height}}).gif({delay:[100,100],loop:0}).toBuffer(),reference:'sharp'},
 {name:'bmp24.bmp',mime:'image/bmp',bytes:ffi(['-f','rawvideo','-pixel_format','rgb24','-video_size',`${width}x${height}`,'-i','pipe:0','-frames:v','1','-c:v','bmp','-pix_fmt','bgr24','-f','image2pipe','pipe:1'],raw),reference:'ffmpeg'},
 {name:'tiff-lzw.tiff',mime:'image/tiff',bytes:await staticImage().tiff({compression:'lzw'}).toBuffer(),reference:'sharp'},
 {name:'apng-two-frames.png',mime:'image/png',bytes:ffi(['-f','rawvideo','-pixel_format','rgb24','-video_size',`${width}x${height}`,'-framerate','2','-i','pipe:0','-frames:v','2','-plays','0','-f','apng','pipe:1'],Buffer.concat([raw,second])),reference:'ffmpeg'},
];
const source=await readFile(new URL('../../jessiemessage-audit/public/image-preparation.js',import.meta.url),'utf8');
const results=[];
for(const fixture of fixtures){
 const {mime,bytes,reference}=fixture; const name='format-rejections-'+fixture.name;
 await writeFile(new URL(name,dir),bytes);
 let meta,decoded;
 if(reference==='sharp'){
  meta=await sharp(bytes).metadata();
  decoded=await sharp(bytes,{page:0,pages:1}).png().toBuffer();
 }else{
  meta=JSON.parse(execFileSync('ffprobe',['-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_read_frames','-of','json',fileURLToPath(new URL(name,dir))],{maxBuffer:1024*1024}).toString()).streams[0];
  decoded=ffi(['-i',fileURLToPath(new URL(name,dir)),'-frames:v','1','-c:v','png','-f','image2pipe','pipe:1']);
 }
 const normalized=await sharp(decoded).raw().toBuffer({resolveWithObject:true});
 if(normalized.info.width!==width||normalized.info.height!==height||!normalized.data.some(v=>v>100))throw Error('Invalid reference decode '+name);
 let inspection;
 try{inspection={ok:true,value:inspectImageInput(bytes)}}catch(error){inspection={ok:false,code:error.code}}
 let nativeCalls=0;
 const context=vm.createContext({Blob,ArrayBuffer,Uint8Array,DataView,Uint8ClampedArray,DOMException,setTimeout,clearTimeout,
  createImageBitmap:async()=>{nativeCalls++;return{width,height,close(){}}},document:{createElement(){throw Error('native preparation unexpectedly reached')}}});
 vm.runInContext(source.replace(/export /g,'')+'\nglobalThis.prepare=prepareImageUpload;',context);
 let preparation;
 try{await context.prepare(new Blob([bytes],{type:mime}));preparation={ok:true}}catch(error){preparation={ok:false,code:error.code??error.name}}
 results.push({name,mime,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),reference,
  referenceMetadata:{format:meta.format??meta.codec_name,width:meta.width,height:meta.height,pages:meta.pages??Number(meta.nb_read_frames??1)},
  firstFrameDecoded:true,inspection,preparation,nativeCalls});
}
await writeFile(new URL('format-rejections-results.json',dir),JSON.stringify({scope:'new targeted synthetic probes only, no real customer media or network',width,height,results},null,2)+'\n');
console.log(JSON.stringify(results));
