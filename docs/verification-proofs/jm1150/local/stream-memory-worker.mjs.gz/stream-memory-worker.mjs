const pending = []; const capture = message => pending.push(message); process.on("message", capture);
const send = process.send.bind(process);
process.send = (message, ...args) => send({ ...message, probeUsage: process.resourceUsage() }, ...args);
await import("file:///workspace/scratch/2a0dbdfc70cc/jessiemessage-audit/server/media/image-worker.mjs");

process.off("message", capture); for (const message of pending) process.emit("message", message);
