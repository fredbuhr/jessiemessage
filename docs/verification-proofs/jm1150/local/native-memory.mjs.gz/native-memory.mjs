import sharp from '/workspace/scratch/2a0dbdfc70cc/jessiemessage-audit/node_modules/sharp/dist/index.mjs';
import { readFile,writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
sharp.cache(false);sharp.concurrency(1);
const base='/workspace/scratch/2a0dbdfc70cc/implementation-notes/photo-acceptance';
const solid=()=>sharp({create:{width:8000,height:6000,channels:3,background:{r:60,g:80,b:120}}});
await writeFile(base+'/synthetic-48mp-interlaced.png',await solid().png({progressive:true}).toBuffer());
await writeFile(base+'/synthetic-48mp.tiff',await solid().tiff({compression:'deflate'}).toBuffer());
const results=[];
for(const file of ['synthetic-6000x4000.jpg','synthetic-8000x6000.jpg','synthetic-48mp-interlaced.png','synthetic-48mp.tiff']){
const code=`import sharp from '/workspace/scratch/2a0dbdfc70cc/jessiemessage-audit/node_modules/sharp/dist/index.mjs';import{readFile}from'node:fs/promises';sharp.cache(false);sharp.concurrency(1);const bytes=await readFile(${JSON.stringify(base+'/'+file)});const start=Date.now();try{const full=await sharp(bytes,{failOn:'warning',limitInputPixels:64000000,sequentialRead:true,animated:false}).rotate().resize({width:2048,height:2048,fit:'inside',withoutEnlargement:true}).flatten({background:{r:245,g:238,b:242}}).toColourspace('srgb').jpeg({quality:85}).toBuffer({resolveWithObject:true});const thumb=await sharp(full.data).resize({width:480,height:480,fit:'inside',withoutEnlargement:true}).jpeg({quality:80}).toBuffer();console.log(JSON.stringify({accepted:true,inputBytes:bytes.length,outputBytes:full.data.length,thumbnailBytes:thumb.length,width:full.info.width,height:full.info.height,ms:Date.now()-start,maxRSSKiB:process.resourceUsage().maxRSS}));}catch(e){console.log(JSON.stringify({accepted:false,error:e.message,maxRSSKiB:process.resourceUsage().maxRSS}));}`;
const child=spawnSync(process.execPath,['--max-old-space-size=96','--input-type=module','-e',code],{encoding:'utf8',timeout:30000});
results.push({file,exit:child.status,...JSON.parse(child.stdout.trim()||'{}')});}
await writeFile(base+'/native-memory.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
